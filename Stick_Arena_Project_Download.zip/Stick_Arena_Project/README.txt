STICK ARENA — PROJECT FILES

HOW TO RUN
1. Extract the complete Stick_Arena_Project folder from the ZIP archive.
2. Open index.html in a modern browser (Chrome, Edge, or Firefox).
3. Keep the css and js folders beside index.html.

The game uses local HTML Canvas, CSS and JavaScript. No external libraries or internet connection are required.

PROJECT STRUCTURE
index.html
css/style.css
js/01_core.js
js/02_combat.js
js/03_modes.js
js/04_render.js
js/05_ui.js
