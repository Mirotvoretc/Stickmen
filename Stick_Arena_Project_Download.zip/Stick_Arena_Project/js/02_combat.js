function teslaFire(e,dm){
 const sx=e.x+e.f*24*e.sz,sy=e.y-38*e.sz;
 let first=null,best=1e9;
 for(const o of ents){if(o.hp<=0||o.tm==e.tm)continue;const dx=o.x-sx,dy=o.y-o.h*.5-sy,d=Math.hypot(dx,dy);if(dx*e.f>0&&d<560&&Math.abs(dy)<170&&d<best){best=d;first=o}}
 if(!first){spark(sx,sy,16,'#63eaff');return}
 hit(first,dm,e,e.f*220);
 ZP.push({x1:sx,y1:sy,x2:first.x,y2:first.y-first.h*.5,life:.24,c:'#63eaff'});
 let second=null,bd=190;
 for(const o of ents){if(o===first||o.hp<=0||o.tm==e.tm)continue;const d=Math.hypot(o.x-first.x,o.y-o.h*.5-(first.y-first.h*.5));if(d<bd){bd=d;second=o}}
 if(second){hit(second,Math.round(dm*.62),e,(Math.sign(second.x-first.x)||1)*130);ZP.push({x1:first.x,y1:first.y-first.h*.5,x2:second.x,y2:second.y-second.h*.5,life:.2,c:'#b8f8ff'})}
 fx(first.x,first.y-first.h*.5,14,'#63eaff',280);G.sh=Math.max(G.sh,5)
}
function updFields(dt){
 if(G.timeField){const f=G.timeField;f.life-=dt;if(f.life<=0)G.timeField=null;else for(const e of ents)if(e.hp>0&&e.tm!=f.tm&&Math.hypot(e.x-f.x,e.y-e.h*.5-f.y)<285)e.tslow=Math.max(e.tslow||0,.22)}
 if(G.gravityField){const f=G.gravityField;f.life-=dt;for(const e of ents)if(e.hp>0&&e.tm!=f.tm){const dx=f.x-e.x,dy=f.y-(e.y-e.h*.5),d=Math.hypot(dx,dy);if(d<f.max&&d>8){const force=(1-d/f.max)*620;e.vx+=dx/d*force*dt;e.vy+=dy/d*force*dt}}
  if(f.life<=0){for(const e of ents)if(e.hp>0&&e.tm!=f.tm&&Math.hypot(e.x-f.x,e.y-e.h*.5-f.y)<f.max)hit(e,f.dm||90,f.src,Math.sign(e.x-f.x)*360);fx(f.x,f.y,70,'#b98cff',560);RG.push({x:f.x,y:f.y,l:.5,big:1});G.sh=Math.max(G.sh,16);G.gravityField=null}}
}
function drawFields(){
 if(G.timeField){const f=G.timeField,r=285,k=.12+.06*Math.sin(G.t*8);cx.save();cx.globalCompositeOperation='lighter';cx.strokeStyle='#8b91ff';cx.globalAlpha=.7;cx.lineWidth=3;cx.beginPath();cx.arc(f.x,f.y,r,0,7);cx.stroke();cx.globalAlpha=.16+k;cx.fillStyle='#8b91ff';cx.beginPath();cx.arc(f.x,f.y,r,0,7);cx.fill();for(let i=0;i<12;i++){const a=G.t*.8+i*Math.PI/6;cx.fillStyle='#d8d9ff';cx.beginPath();cx.arc(f.x+Math.cos(a)*r,f.y+Math.sin(a)*r,4,0,7);cx.fill()}cx.restore()}
 if(G.gravityField){const f=G.gravityField,r=f.max*(.82+.08*Math.sin(G.t*12));cx.save();cx.globalCompositeOperation='lighter';const g=cx.createRadialGradient(f.x,f.y,2,f.x,f.y,r);g.addColorStop(0,'#090514');g.addColorStop(.18,'#4b2388aa');g.addColorStop(.55,'#b98cff33');g.addColorStop(1,'#b98cff00');cx.fillStyle=g;cx.beginPath();cx.arc(f.x,f.y,r,0,7);cx.fill();for(let i=0;i<3;i++){cx.strokeStyle=`rgba(207,160,255,${.55-i*.12})`;cx.lineWidth=3-i*.5;cx.beginPath();cx.ellipse(f.x,f.y,r*(.55+i*.16),r*(.22+i*.05),G.t*(i%2?1:-1),0,7);cx.stroke()}cx.restore()}
 for(const z of ZP){const k=Math.max(0,z.life/.24);cx.save();cx.globalCompositeOperation='lighter';cx.globalAlpha=k;cx.strokeStyle=z.c;cx.lineWidth=8*k+2;cx.beginPath();cx.moveTo(z.x1,z.y1);const mx=(z.x1+z.x2)/2+(R()-.5)*24,my=(z.y1+z.y2)/2+(R()-.5)*24;cx.lineTo(mx,my);cx.lineTo(z.x2,z.y2);cx.stroke();cx.strokeStyle='#ffffff';cx.lineWidth=2*k;cx.stroke();cx.restore()}
}
function startMapEvent(){const spec=MAP_EVENTS[G.mi]||MAP_EVENTS[0];G.ev={...spec,timer:7+R()*5,warning:0,active:0,x:W*.5,dir:R()<.5?-1:1,tick:0,serial:0,fallY:-80,rocks:[]}}
function eventImpact(ev,x,damage=24,radius=120){fx(x,GY-8,36,ev.c,420);fx(x,GY-8,18,'#ffda9a',320);RG.push({x,y:GY-12,l:.55,big:1});G.sh=Math.max(G.sh,7);for(const e of ents)if(e.hp>0&&Math.abs(e.x-x)<radius&&e.y>GY-235)hit(e,damage,null,(Math.sign(e.x-x)||1)*250)}
function triggerMapEvent(ev){ev.serial++;ev.x=140+R()*(W-280);ev.active=0;ev.tick=0;ev.hitDone=0;
 if(ev.type=='meteor'){ev.active=1.25;ev.fallY=-95;ev.hitX=ev.x;G.sh=Math.max(G.sh,2)}
 else if(ev.type=='rockfall'){ev.active=2.2;ev.rocks=Array.from({length:4},(_,i)=>({x:cl(ev.x+(R()-.5)*300,70,W-70),y:-80-R()*210,vy:80+R()*100,done:0}));G.sh=Math.max(G.sh,3)}
 else if(ev.type=='eruption'){ev.active=3.1;ev.tick=.08;fx(ev.x,GY-5,28,'#ff623d',360);RG.push({x:ev.x,y:GY-8,l:.45,big:1});G.sh=Math.max(G.sh,4)}
 else if(ev.type=='bridge'){ev.active=1.5;ev.tick=.05;G.sh=Math.max(G.sh,5);for(let i=0;i<22;i++)PT.push({x:ev.x+(R()-.5)*280,y:GY-10,vx:(R()-.5)*240,vy:-80-R()*250,g:650,l:.5+R()*.5,c:R()<.5?'#d4a36d':'#8d6040',r:3+R()*4});for(const e of ents)if(e.hp>0&&Math.abs(e.x-ev.x)<190){e.vx+=(Math.sign(e.x-ev.x)||1)*(100+R()*80);if(e.og)hit(e,8,null,(Math.sign(e.x-ev.x)||1)*120)}}
 else if(ev.type=='gravity'){ev.active=4.5;G.sh=Math.max(G.sh,3)}
 else if(['gust','icegust','sandstorm'].includes(ev.type)){ev.active=4;ev.dir=R()<.5?-1:1;ev.tick=0;G.sh=Math.max(G.sh,2)}
 else if(ev.type=='dark'){ev.active=4.5;G.sh=Math.max(G.sh,1)}
 else if(ev.type=='roots'||ev.type=='vines'){ev.active=3.6;ev.tick=0;fx(ev.x,GY-4,22,ev.c,240);G.sh=Math.max(G.sh,2)}
}
function updEvent(dt){const ev=G.ev;if(!ev||G.demo||G.pause||G.end)return;
 if(ev.warning>0){ev.warning-=dt;if(ev.warning<=0)triggerMapEvent(ev)}
 if(ev.active>0){ev.active-=dt;
  if(ev.type=='meteor'&&!ev.hitDone){ev.fallY+=940*dt;if(R()<dt*65)PT.push({x:ev.hitX+(R()-.5)*18,y:ev.fallY,vx:(R()-.5)*35,vy:120,g:0,l:.28,c:'#ffb36a',r:2+R()*3});if(ev.fallY>=GY-42){ev.hitDone=1;eventImpact(ev,ev.hitX,26,125);ev.active=Math.max(ev.active,.45)}}
  if(ev.type=='rockfall'){for(const rock of ev.rocks){if(rock.done)continue;rock.vy+=720*dt;rock.y+=rock.vy*dt;if(rock.y>=GY-28){rock.done=1;eventImpact(ev,rock.x,18,88);for(let k=0;k<8;k++)PT.push({x:rock.x,y:GY-12,vx:(R()-.5)*220,vy:-80-R()*180,g:600,l:.35+R()*.35,c:'#c8a27b',r:2+R()*3})}else if(R()<dt*34)PT.push({x:rock.x+(R()-.5)*10,y:rock.y,vx:(R()-.5)*45,vy:80,g:0,l:.25,c:'#c4a17a',r:2+R()*2})}if(ev.rocks.every(r=>r.done))ev.active=Math.min(ev.active,.25)}
  if(ev.type=='eruption'){ev.tick-=dt;if(ev.tick<=0){ev.tick=.36;for(let k=0;k<15;k++){const a=-Math.PI/2+(R()-.5)*.95,v=180+R()*390;PT.push({x:ev.x+(R()-.5)*34,y:GY-10,vx:Math.cos(a)*v,vy:Math.sin(a)*v-150,g:620,l:.55+R()*.55,c:['#ff3e1f','#ff7928','#ffc04d','#ffe08a'][R()*4|0],r:3+R()*5})}RG.push({x:ev.x,y:GY-6,l:.3});G.sh=Math.max(G.sh,2.4);for(const e of ents)if(e.hp>0&&e.og&&Math.abs(e.x-ev.x)<138)hit(e,8,null,(Math.sign(e.x-ev.x)||1)*90)}}
  if(['gust','icegust','sandstorm'].includes(ev.type)){for(const e of ents)if(e.hp>0)e.vx+=ev.dir*(ev.type=='sandstorm'?110:ev.type=='icegust'?180:145)*dt;ev.tick-=dt;if(ev.tick<=0){ev.tick=.08;for(let i=0;i<(ev.type=='sandstorm'?5:3);i++){const y=70+R()*500;PT.push({x:ev.dir>0?-12:W+12,y,vx:ev.dir*(ev.type=='sandstorm'?360:ev.type=='icegust'?480:390),vy:(R()-.5)*35,g:0,l:.6,c:ev.type=='icegust'?'#bfefff':ev.type=='sandstorm'?'#e5bd82':'#a8dff0',r:ev.type=='sandstorm'?2+R()*3:1.5+R()*2})}}}
  if(ev.type=='roots'||ev.type=='vines'){ev.tick-=dt;if(ev.tick<=0){ev.tick=.3;for(const e of ents)if(e.hp>0&&Math.abs(e.x-ev.x)<(ev.type=='vines'?125:95)&&e.og){st(e,'sl',ev.type=='vines'?.55:.42);if(ev.type=='vines')e.vx+=(Math.sign(e.x-ev.x)||1)*-55}}}
 }
 if(ev.active<=0&&ev.warning<=0){ev.timer-=dt;if(ev.timer<=0){ev.warning=1.45;ev.x=140+R()*(W-280);ev.timer=13+R()*5;ev.hitDone=0;TX.push({x:W/2,y:150,t:ev.name.toUpperCase(),l:1.3,c:ev.c})}}
}
function drawEvent(){const ev=G.ev;if(!ev||G.demo)return;cx.save();cx.lineCap='round';cx.lineJoin='round';
 if(ev.warning>0){const p=1-ev.warning/1.45;cx.globalAlpha=.35+.35*Math.sin(G.t*18);cx.strokeStyle=ev.c;cx.lineWidth=5;cx.beginPath();cx.arc(ev.x,GY-20,30+65*p,0,7);cx.stroke();cx.globalAlpha=.9;cx.fillStyle=ev.c;cx.font='bold 17px system-ui';cx.textAlign='center';cx.fillText(ev.name.toUpperCase(),W/2,122)}
 if(ev.active>0){
  if(ev.type=='meteor'&&!ev.hitDone){cx.save();cx.globalCompositeOperation='lighter';const y=ev.fallY,g=cx.createRadialGradient(ev.hitX,y,2,ev.hitX,y,35);g.addColorStop(0,'#fff7c2');g.addColorStop(.25,'#ffb34d');g.addColorStop(1,'#ff4b1800');cx.fillStyle=g;cx.beginPath();cx.arc(ev.hitX,y,35,0,7);cx.fill();cx.strokeStyle='#fff0bb';cx.lineWidth=7;cx.beginPath();cx.moveTo(ev.hitX,y-20);cx.lineTo(ev.hitX-18,y-75);cx.stroke();cx.restore()}
  if(ev.type=='rockfall'){cx.save();cx.globalCompositeOperation='lighter';for(const r of ev.rocks)if(!r.done){cx.fillStyle='#9a795a';cx.strokeStyle='#e7c69b';cx.lineWidth=3;cx.beginPath();cx.moveTo(r.x-13,r.y-8);cx.lineTo(r.x-5,r.y-20);cx.lineTo(r.x+11,r.y-14);cx.lineTo(r.x+15,r.y+4);cx.lineTo(r.x-5,r.y+10);cx.closePath();cx.fill();cx.stroke();cx.strokeStyle='#ffc77a';cx.lineWidth=5;cx.beginPath();cx.moveTo(r.x,r.y-22);cx.lineTo(r.x-7,r.y-44);cx.stroke()}cx.restore()}
  if(ev.type=='eruption'){cx.save();cx.globalCompositeOperation='lighter';const pulse=.8+.2*Math.sin(G.t*18),g=cx.createRadialGradient(ev.x,GY-4,3,ev.x,GY-4,190);g.addColorStop(0,'#fff2a8cc');g.addColorStop(.25,'#ff7b28a8');g.addColorStop(.7,'#ff3b1670');g.addColorStop(1,'#ff2a1200');cx.fillStyle=g;cx.beginPath();cx.ellipse(ev.x,GY-18,165*pulse,92,0,Math.PI,Math.PI*2);cx.fill();for(let i=0;i<7;i++){const x=ev.x+(i-3)*26+Math.sin(G.t*8+i)*8,h=70+((i*43+Math.floor(G.t*18)%55)%120);cx.fillStyle=i%2?'#ff6a20':'#ffc04d';cx.beginPath();cx.moveTo(x-8,GY);cx.quadraticCurveTo(x-17,GY-h*.45,x+Math.sin(G.t*9+i)*9,GY-h);cx.quadraticCurveTo(x+16,GY-h*.45,x+8,GY);cx.fill()}cx.restore()}
  if(ev.type=='bridge'){cx.globalAlpha=.25+.12*Math.sin(G.t*30);cx.fillStyle='#d6a36f';cx.fillRect(0,GY-7,W,13);cx.globalAlpha=.9;for(let i=0;i<18;i++){const x=i*74+(G.t*85%74);cx.strokeStyle='#3d281c';cx.lineWidth=3;cx.beginPath();cx.moveTo(x,GY-16);cx.lineTo(x+18,GY+5);cx.stroke()}}
  if(ev.type=='dark'){cx.globalAlpha=.62;cx.fillStyle='#08091c';cx.fillRect(0,0,W,H);cx.globalAlpha=.8;cx.strokeStyle='#a5b3ff';cx.lineWidth=4;cx.beginPath();cx.arc(W-150,116,46,0,7);cx.stroke();cx.fillStyle='#08091c';cx.beginPath();cx.arc(W-132,102,43,0,7);cx.fill()}
  if(ev.type=='gravity'){cx.globalAlpha=.13;cx.fillStyle='#b98cff';cx.fillRect(0,0,W,H);cx.globalAlpha=.5;for(let i=0;i<4;i++){cx.strokeStyle='#d7adff';cx.lineWidth=2;cx.beginPath();cx.ellipse(W/2,H/2,120+i*75,35+i*25,G.t*(i%2?1:-1),0,7);cx.stroke()}}
  if(ev.type=='gust'||ev.type=='icegust'||ev.type=='sandstorm'){cx.globalAlpha=ev.type=='sandstorm'?.4:.28;cx.strokeStyle=ev.c;cx.lineWidth=ev.type=='sandstorm'?5:3;for(let i=0;i<13;i++){const y=55+i*48,x=(G.t*420*ev.dir+i*173)%(W+300)-150;cx.beginPath();cx.moveTo(x,y);cx.lineTo(x-ev.dir*(ev.type=='sandstorm'?175:130),y-8);cx.stroke()}}
  if(ev.type=='roots'||ev.type=='vines'){cx.globalAlpha=.8;cx.strokeStyle=ev.c;cx.lineWidth=ev.type=='vines'?7:9;for(let i=-3;i<=3;i++){const x=ev.x+i*(ev.type=='vines'?19:24),h=(ev.type=='vines'?190:150)+Math.sin(G.t*5+i)*12;cx.beginPath();cx.moveTo(x,GY);cx.bezierCurveTo(x-28,GY-h*.25,x+25,GY-h*.7,x+Math.sin(G.t*6+i)*12,GY-h);cx.stroke();if(ev.type=='vines'){cx.fillStyle='#8ce77b';cx.beginPath();cx.ellipse(x+13,GY-h*.48,12,4,.6,0,7);cx.fill()}}}
  cx.globalAlpha=.9;cx.fillStyle=ev.c;cx.font='bold 15px system-ui';cx.textAlign='center';cx.fillText(ev.name.toUpperCase(),W/2,122)}
 cx.restore()}
function fire(e){const w=WP[e.wp],x=e.x+e.f*22*e.sz,y=e.y-38*e.sz,dm=w.dm*(e.rg?2:CH[e.ch].dm||1)*(e.dm||1)*(e.boost>0&&CH[e.ch].assault?1.12:1);e.cd=w.cd;
 if(w.t=='k'){e.sw=.3;let nh=0;const air=!e.og&&e.wp=='hamm';for(const o of ents)if(o.hp>0&&o.tm!=e.tm&&Math.abs(o.x-e.x-e.f*(w.cx||36))<(w.rn||60)+o.w/2&&o.y>e.y-100&&o.y-o.h<e.y+8){nh++;hit(o,air?dm*1.1:dm,e,e.f*(e.wp=='hamm'?(air?1200:900):420))}fx(e.x+e.f*46,e.y-34,12,'#fff',320);spark(e.x+e.f*46,e.y-34,8,'#fff');if(air&&nh){RG.push({x:e.x+e.f*46,y:e.y-20,l:.3});G.sh=Math.max(G.sh,10)}if(e.wp=='katana'&&nh){e.katHits=(e.katHits||0)+1;if(e.katHits>=10)brk(e)}else if(e.wp!='katana')use(e);return}
 if(w.t=='x'){e.rb={t:0,a:null,tk:0};e.wp='fist';e.am=1e9;TX.push({x:e.x,y:e.y-e.h-20,t:'РАДУЖНЫЙ ЗАЛП!',l:1.2,c:'#ff9ae6'});return}
 if(w.t=='l'){e.chg=w.ch;return}
 if(w.t=='e'){teslaFire(e,dm);use(e);return}
 if(w.t=='m'){e.mirror=15;fx(e.x,e.y-e.h*.5,26,'#a8e9ff',300);TX.push({x:e.x,y:e.y-e.h-20,t:'ЗЕРКАЛО · 15 СЕК',l:1.1,c:'#a8e9ff'});use(e);return}
 if(w.t=='u'){G.timeField={x:e.x,y:e.y-e.h*.5,tm:e.tm,life:10,src:e};fx(e.x,e.y-e.h*.5,35,'#8b91ff',360);TX.push({x:e.x,y:e.y-e.h-20,t:'ВРЕМЯ ЗАМЕДЛЕНО',l:1.1,c:'#aeb2ff'});use(e);return}
 if(w.t=='v'){G.gravityField={x:e.x+e.f*170,y:e.y-e.h*.55,tm:e.tm,life:3.4,max:230,dm:90,src:e};fx(e.x+e.f*170,e.y-e.h*.55,28,'#b98cff',360);TX.push({x:e.x,y:e.y-e.h-20,t:'ГРАВИТАЦИОННЫЙ КОЛЛАПС',l:1.2,c:'#cdaaff'});use(e);return}
 e.rc=.1;fx(x,y,3,'#fff1b0',150);if(w.t=='b'&&!w.pel)PT.push({x:e.x,y:y+4,vx:-e.f*(50+R()*80),vy:-220,l:.7,c:'#d9b44a',r:2});for(let i=0;i<(w.pel||1);i++){const a=(R()-.5)*(w.sp||0)*2-(w.t=='s'?.1:w.t=='g'?.45:0);pr({x,y,vx:Math.cos(a)*w.v*e.f,vy:Math.sin(a)*w.v,dm,tm:e.tm,t:w.t,col:w.c,life:w.life||(w.t=='r'?3.6:w.t=='q'?3.2:1.6),src:e,g:w.t=='s'?600:w.t=='g'?900:w.t=='n'?250:0,fz:w.fz})}
 e.vx-=e.f*(w.pel?240:w.t=='r'?140:0);use(e)}
function beam(e){if(e.wp!='laser'||e.hp<=0)return;const x=e.x+e.f*24*e.sz,y=e.y-38*e.sz,dm=WP.laser.dm*(e.rg?2:CH[e.ch].dm||1)*(e.dm||1)*(e.boost>0&&CH[e.ch].assault?1.12:1);BM.push({x,y,f:e.f,l:.25});G.sh=Math.max(G.sh,7);fx(x,y,10,'#d46bff',300);
 for(const o of ents)if(o.hp>0&&o.tm!=e.tm&&(o.x-x)*e.f>0&&y>o.y-o.h-8&&y<o.y+4)hit(o,dm,e,e.f*380);use(e)}
function boom(p){fx(p.x,p.y,30,'#ffb347',380);fx(p.x,p.y,14,'#666',200);G.sh=Math.max(G.sh,12);RG.push({x:p.x,y:p.y,l:.3});
 for(const o of ents)if(o.hp>0&&o.tm!=p.tm){const d=Math.hypot(o.x-p.x,o.y-o.h/2-p.y),r=100+o.w*.5;if(d<r)hit(o,p.dm*(1-d/r*.55),p.src,Math.sign(o.x-p.x)*420)}}
function upd(e,dt){const c=CH[e.ch],I=e.fz>0?{}:e.in;e.cd-=dt*(e.tslow>0?.45:1);e.fz-=dt;e.mirror=Math.max(0,(e.mirror||0)-dt);e.tslow=Math.max(0,(e.tslow||0)-dt);e.fl-=dt;e.dr-=dt;e.sw-=dt;e.rc-=dt;e.rf-=dt;e.kc-=dt;e.sl-=dt;e.boost=Math.max(0,(e.boost||0)-dt);if(e.rb)rbUpd(e,dt);if(c.med&&e.hp>0){e.mt=Math.min(20,(e.mt||0)+dt);if(e.mt>=20&&e.hp<e.mh){e.mt=0;e.hp=Math.min(e.mh,e.hp+10);TX.push({x:e.x,y:e.y-e.h-10,t:'+10',l:.8,c:'#7ee08a'});fx(e.x,e.y-e.h/2,8,'#7ee08a',140)}}if(c.rage&&e.hp>0){const q=e.hp/e.mh;if(q>=.45)e.rgd=0;if(!e.rg&&!e.rgd&&q<.45){e.rg=1;fx(e.x,e.y-e.h/2,24,'#ff3b3b',420);G.sh=Math.max(G.sh,8);TX.push({x:e.x,y:e.y-e.h-24,t:'ЯРОСТЬ!',l:1.2,c:'#ff6b4a'})}if(e.rg){dot(e,2*dt,'#ff8a7a');if(R()<dt*30)pf(e,'#ff3b3b',-120,-50);if(e.hp<=e.mh*.2){e.rg=0;e.rgd=1}}}if(e.bn>0){e.bn-=dt;dot(e,7*dt,'#ff9a2e');if(R()<dt*30)pf(e,R()<.5?'#ff9a2e':'#ffd25a',-150,-60)}if(e.br>0){e.br-=dt;dot(e,3*e.bl*dt,'#ff5a6a');if(R()<dt*(8+e.bl*7))PT.push({x:e.x+(R()-.5)*12,y:e.y-R()*e.h*.8,vx:(R()-.5)*40,vy:-20,l:.55,c:'#c1121f',r:1.8+R()});if(e.br<=0)e.bl=0}if(e.sl>0&&R()<dt*14)pf(e,'#9fe3ff',20,-10);if(e.fz>0&&R()<dt*12)pf(e,'#e6f8ff',30,10);if(e.zk=='f'&&R()<dt*25)pf(e,'#ff9a2e',-150,-60);if(e.zk=='i'&&R()<dt*10)pf(e,'#bfeaff',20,10);
 if(e.chg>0){e.chg-=dt;if(e.chg<=0)beam(e)}
 const t=(I.r?1:0)-(I.l?1:0),sp=290*(c.sp||1)*(e.spm||1)*(e.boost>0?1.58:1)*(e.chg>0?.25:1)*(e.wp=='mini'&&e.cd>0?.6:1)*(e.sl>0?.5:1)*(e.rb?(e.rb.t<1.5?.1:.55):1)*(e.tslow>0?.38:1);
 e.vx+=(t*sp-e.vx)*Math.min(1,dt*(e.og?(M.ic?3.5:14):5));if(t)e.f=t;if(e.fo)e.f=e.fo;
 if(I.j&&!e.pj){if(e.og){e.vy=-720*(c.jm||1);e.dj=c.dj||0}else if(e.dj>0){e.vy=-650;e.dj--;fx(e.x,e.y,8,'#fff',120)}}e.pj=I.j;
 if(I.d&&e.og&&e.y<GY)e.dr=.22;
 if(I.s&&e.cd<=0&&e.chg<=0&&!e.rb)fire(e);
 if(I.m&&!e.pm&&e.kc<=0){if(c.med){e.kc=12;pr({x:e.x+e.f*14,y:e.y-44*e.sz,vx:e.f*340+e.vx*.3,vy:-420,g:900,tm:e.tm,t:'h',life:4,src:e});TX.push({x:e.x,y:e.y-e.h-14,t:'АПТЕЧКА',l:.7,c:'#7ee08a'})}else if(c.engineer){e.kc=14;TUR.push({x:cl(e.x+e.f*48,28,W-28),y:e.y,tm:e.tm,life:6,cd:.25,angle:e.f>0?0:Math.PI,c:e.c,src:e});fx(e.x,e.y-8,12,'#8ce5ff',180);TX.push({x:e.x,y:e.y-e.h-14,t:'ТУРЕЛЬ!',l:.8,c:'#8ce5ff'})}else if(c.duelist){e.kc=12;e.mirror=1.35;fx(e.x,e.y-e.h*.5,18,'#b5f5ff',260);TX.push({x:e.x,y:e.y-e.h-14,t:'ПАРИРОВАНИЕ',l:.8,c:'#b5f5ff'})}else if(c.assault){e.kc=13;e.boost=2.5;fx(e.x,e.y-14,18,'#ffb05a',250);TX.push({x:e.x,y:e.y-e.h-14,t:'БОЕВОЙ РЫВОК',l:.8,c:'#ffb05a'})}}e.pm=I.m;
 e.vy+=1600*dt*(M.gv||1)*(G.ev&&G.ev.type=='gravity'&&G.ev.active>0?.42:1)*(e.vy>0?(c.fg||1):1);if(c.sf&&e.vy>170)e.vy=170;const py=e.y,w0=e.og,v0=e.vy;e.x=cl(e.x+e.vx*dt,14,W-14);e.y+=e.vy*dt;e.og=0;
 if(e.y>=GY){e.y=GY;e.vy=0;e.og=1}else if(e.vy>=0&&e.dr<=0)for(const p of M.pl)if(e.x>p[0]-4&&e.x<p[0]+p[2]+4&&py<=p[1]+1&&e.y>=p[1]){e.y=p[1];e.vy=0;e.og=1}
 if(e.og&&!w0&&v0>420){fx(e.x,e.y,7,'#ffffff77',120);if(c.slam)tslam(e)}if(e.og&&Math.abs(e.vx)>200&&R()<dt*16)PT.push({x:e.x-Math.sign(e.vx)*8,y:e.y-1,vx:-e.vx*.1,vy:-25,g:0,l:.3,c:'#ffffff66',r:2+R()*2});if(e.ch==3&&Math.abs(e.vx)>120&&R()<dt*40)pf(e,'#cfeaff',0,-10);e.ph+=Math.abs(e.vx)*dt*.07}
function near(e){let t=null,b=1e9;for(const o of ents)if(o.hp>0&&o.tm!=e.tm){const d=Math.abs(o.x-e.x)+Math.abs(o.y-e.y)*.6;if(d<b){b=d;t=o}}return t}
function platformForPoint(x,y){let best=null,bd=1e9;for(const p of M.pl){if(x<p[0]-16||x>p[0]+p[2]+16)continue;const d=Math.abs(p[1]-y);if(d<58&&d<bd){bd=d;best=p}}return best}
function aiNavigate(e,x,y,I,dt){const goal=platformForPoint(x,y);let current=-1;for(let i=0;i<M.pl.length;i++){const p=M.pl[i];if(e.x>=p[0]-8&&e.x<=p[0]+p[2]+8&&Math.abs(e.y-p[1])<18){current=i;break}}
 if(e.og)e.aiPlatform=current;else if(e.aiPlatform!=null)current=e.aiPlatform;
 const goalIndex=goal?M.pl.indexOf(goal):-1,currentY=current<0?GY:M.pl[current][1],goalY=goal?goal[1]:y+8;
 if(y<e.y-48&&currentY>goalY+18&&goalIndex>=0){const nodes=[[0,GY,W],...M.pl],from=current+1,to=goalIndex+1,prev=Array(nodes.length).fill(-1),queue=[from];prev[from]=from;
  for(let q=0;q<queue.length&&prev[to]<0;q++){const a=queue[q],pa=nodes[a];for(let b=1;b<nodes.length;b++){if(prev[b]>=0||b==a)continue;const pb=nodes[b],rise=pa[1]-pb[1],gap=Math.max(0,pb[0]-(pa[0]+pa[2]),pa[0]-(pb[0]+pb[2]));if(rise>22&&rise<=155&&gap<=260){prev[b]=a;queue.push(b)}}}
  if(prev[to]>=0&&from!==to){let path=[to];while(path[0]!=from)path.unshift(prev[path[0]]);const next=nodes[path[1]],sx=next[0]+next[2]/2,dx=sx-e.x;if(Math.abs(dx)>20)(dx>0?I.r=1:I.l=1);if(e.og&&e.aiJumpCd<=0&&Math.abs(dx)<235&&currentY-next[1]<=155){I.j=1;e.aiJumpCd=.9}return 1}}
 if(y>e.y+78&&e.og&&e.y<GY-12)I.d=1;
 return 0}
function bot(e,dt){const I=e.in={};e.at=(e.at||0)-dt;e.ai=e.ai||['aggressive','cautious','collector'][R()*3|0];e.aiJumpCd=Math.max(0,(e.aiJumpCd||0)-dt);
 if(e.at<=0){e.at=.16+R()*.16;e.tg=near(e);e.pk=null;let best=1e9;for(const i of IT){const d=Math.abs(i.x-e.x)+Math.abs(i.y-e.y)*.65;const useful=i.kit?e.hp<e.mh*.82:(e.wp=='fist'||e.am<=2||e.ai=='collector');if(useful&&d<best&&d<900){best=d;e.pk=i}}}
 const t=e.tg&&e.tg.hp>0?e.tg:near(e),item=e.pk&&IT.includes(e.pk)?e.pk:null;
 const needsItem=item&&(e.ai=='collector'||e.wp=='fist'||e.am<=2||item.kit&&e.hp<e.mh*.82);
 if(needsItem&&(!t||e.ai=='collector'||e.wp=='fist')){const dx=item.x-e.x,dy=item.y-e.y;e.fo=Math.sign(dx)||e.f;const nav=aiNavigate(e,item.x,item.y,I,dt);if(!nav&&Math.abs(dx)>28)(dx>0?I.r=1:I.l=1);if(Math.abs(dx)<38&&Math.abs(dy)<90){if(item.kit&&e.hp<e.mh*.7)I.j=0;else if(item.wp&&item.wp=='rain')I.j=0}return}
 if(!t)return;const dx=t.x-e.x,dy=t.y-e.y,ad=Math.abs(dx),weapon=e.wp,melee=['fist','katana','hamm'].includes(weapon),short=['shot','fire','tesla','harpoon','boomerang'].includes(weapon),range=melee?58:short?190:weapon=='snip'||weapon=='laser'?470:350;
 e.fo=Math.sign(dx)||e.f;const navigating=aiNavigate(e,t.x,t.y,I,dt);
 if(!navigating&&e.ai=='cautious'){
  if(ad<range*.72){dx>0?I.l=1:I.r=1}else if(ad>range*1.05){dx>0?I.r=1:I.l=1}
  if(ad<150&&e.og&&e.aiJumpCd<=0&&Math.abs(dy)<55&&R()<dt*1.2){I.j=1;e.aiJumpCd=.75}
 }else if(!navigating&&e.ai=='collector'){
  if(ad>range*.9){dx>0?I.r=1:I.l=1}else if(ad<range*.5&&melee){dx>0?I.r=1:I.l=1}
  if(ad<90&&e.og&&e.aiJumpCd<=0&&Math.abs(dy)<55&&R()<dt*.8){I.j=1;e.aiJumpCd=.8}
 }else if(!navigating){
  if(ad>range*.8){dx>0?I.r=1:I.l=1}else if(ad<range*.35&&melee){dx>0?I.l=1:I.r=1}
  if(ad<130&&e.og&&e.aiJumpCd<=0&&Math.abs(dy)<55&&R()<dt*1.2){I.j=1;e.aiJumpCd=.75}
 }
 if(!navigating&&dy>90&&e.og&&e.y<GY-12)I.d=1;
 const vertical=Math.abs(dy)<(melee?100:170);if(vertical&&ad<(melee?95:range+80)&&e.cd<=0)I.s=1;
 if(e.ch==5&&e.hp<e.mh*.72&&e.kc<=0)I.m=1;
 if(e.ch==7&&e.kc<=0&&ad>90&&ad<430)I.m=1;
 if(e.ch==8&&e.kc<=0&&P.some(p=>p.tm!=e.tm&&Math.hypot(p.x-e.x,p.y-e.y)<190))I.m=1;
 if(e.ch==9&&e.kc<=0&&ad<range*1.35)I.m=1;
}
function zom(e,dt){const I=e.in={},t=near(e);if(!t)return;const dx=t.x-e.x;dx>0?I.r=1:I.l=1;if(t.y-e.y<-60&&e.og&&R()<dt*3)I.j=1;if(t.y-e.y>60&&e.y<GY&&R()<dt*2)I.d=1;
 if(Math.abs(dx)<24+e.w/2&&t.y>e.y-e.h&&t.y-t.h<e.y&&e.cd<=0){e.cd=.8;hit(t,e.dmg,e,e.f*200);if(e.zk=='i')st(t,'sl',3.5);if(e.zk=='f')st(t,'bn',3)}}
function bossAI(e,dt){const I=e.in={},t=near(e);if(!t)return;const dx=t.x-e.x,ad=Math.abs(dx),spec=BOSS_TYPES.find(b=>b.id==e.btype)||BOSS_TYPES[0];e.fo=dx>0?1:-1;e.spm=spec.speed+.035*Math.min(G.lv,8);e.bt=(e.bt??1.8)-dt;
 if(e.slam>0&&(e.slam-=dt)<=0)e.sl2=1;
 if(e.sl2&&e.og){e.sl2=0;G.sh=18;RG.push({x:e.x,y:e.y,l:.5,big:1});fx(e.x,e.y,34,e.btype=='electric'?'#63eaff':'#a24dff',460);for(const o of ents)if(o.hp>0&&o.tm!=e.tm&&Math.abs(o.x-e.x)<(e.btype=='colossus'?225:185)&&o.y>e.y-42)hit(o,e.btype=='colossus'?32:24,e,(Math.sign(o.x-e.x)||1)*500)}
 if(e.btype=='necromancer'){
  if(ad<250)dx>0?I.l=1:I.r=1;else if(ad>330)dx>0?I.r=1:I.l=1;
  e.summon=(e.summon??5)-dt;if(e.summon<=0&&ents.filter(o=>o.z&&o.hp>0).length<7){e.summon=6.5;spawnZ(G.lv*2,e.x-e.f*55,e.y);if(R()<.5)spawnZ(G.lv*2,e.x+e.f*55,e.y);fx(e.x,e.y-45,32,'#a24dff',360);TX.push({x:e.x,y:e.y-e.h-20,t:'ПРИЗЫВ НЕКРОМАНТА',l:1.1,c:'#d9a0ff'})}
  if(e.bt<=0){e.bt=2.3+R()*.6;for(let i=-1;i<=1;i++){const a=i*.2;pr({x:e.x+e.f*60,y:e.y-115,vx:Math.cos(a)*e.f*390,vy:Math.sin(a)*390,dm:19,tm:e.tm,col:'#b76bff',src:e,t:'r',life:4})}}
 }else if(e.btype=='electric'){
  if(ad>145)dx>0?I.r=1:I.l=1;else if(ad<90)dx>0?I.l=1:I.r=1;
  if(e.bt<=0){e.bt=2.8+R()*.5;const tx=t.x,ty=t.y-t.h*.5,sx=e.x+e.f*35,sy=e.y-70;ZP.push({x1:sx,y1:sy,x2:tx,y2:ty,life:.24,c:'#63eaff'});for(const o of ents)if(o.hp>0&&o.tm==0&&Math.hypot(o.x-tx,o.y-o.h*.5-ty)<105)hit(o,28,e,(Math.sign(o.x-e.x)||1)*280);fx(tx,ty,22,'#63eaff',340);G.sh=Math.max(G.sh,8)}
 }else if(e.btype=='colossus'){
  if(ad>110)dx>0?I.r=1:I.l=1;
  if(e.bt<=0&&e.og){e.bt=3.4; e.vy=-840;e.vx=Math.sign(dx)*300;e.slam=.72;TX.push({x:e.x,y:e.y-e.h-18,t:'УДАР КОЛОССА',l:.8,c:'#e5c28d'})}
 }else{
  if(ad>170)dx>0?I.r=1:I.l=1;
  if(e.bt<=0){const a=R()*3|0,x=e.x+e.f*70,y=e.y-120;e.bt=1.8+R()*1.1;
   if(a==0)for(let i=-3;i<=3;i++){const an=i*.17;pr({x,y,vx:Math.cos(an)*e.f*540,vy:Math.sin(an)*540,dm:10,tm:e.tm,col:'#ff5a8a',src:e})}
   else if(a==1){e.vy=-760;e.slam=.3;e.vx=Math.sign(dx)*220}
   else for(let i=0;i<2;i++)pr({x,y:y-i*30,vx:e.f*260,vy:-120,dm:20,tm:e.tm,t:'r',life:4,src:e})}
 }
}
function updTurrets(dt){for(const t of TUR){t.life-=dt;t.cd-=dt;let target=null,best=470;for(const o of ents){if(o.hp<=0||o.tm==t.tm)continue;const d=Math.hypot(o.x-t.x,(o.y-o.h*.55)-(t.y-22));if(d<best){best=d;target=o}}if(target){const dx=target.x-t.x,dy=target.y-target.h*.55-(t.y-22);t.angle=Math.atan2(dy,dx);if(t.cd<=0){t.cd=.62;const d=Math.max(1,Math.hypot(dx,dy));pr({x:t.x+Math.cos(t.angle)*16,y:t.y-22+Math.sin(t.angle)*16,vx:dx/d*650,vy:dy/d*650,dm:11,tm:t.tm,t:'b',col:'#8ce5ff',life:1.1,src:t.src});fx(t.x+Math.cos(t.angle)*17,t.y-22+Math.sin(t.angle)*17,3,'#8ce5ff',80)}}}TUR=TUR.filter(t=>{if(t.life>0)return 1;fx(t.x,t.y-8,10,'#8ce5ff',150);return 0})}
function updP(dt){for(const p of P){p.life-=dt;p.age+=dt;
 if(p.t=='r'){if(p.age>.35){let tg=null,bd=1e9;for(const o of ents)if(o.hp>0&&o.tm!=p.tm){const d=Math.hypot(o.x-p.x,o.y-o.h/2-p.y);if(d<bd){bd=d;tg=o}}
  if(tg){const ca=Math.atan2(p.vy,p.vx);let da=Math.atan2(tg.y-tg.h/2-p.y,tg.x-p.x)-ca;da=Math.atan2(Math.sin(da),Math.cos(da));const na=ca+cl(da,-2.3*dt,2.3*dt),sp=Math.min(460,Math.hypot(p.vx,p.vy)+260*dt);p.vx=Math.cos(na)*sp;p.vy=Math.sin(na)*sp}}
  PT.push({x:p.x,y:p.y,vx:R()*30-15,vy:R()*30-15,l:.45,c:p.col||'#c9c9c9',r:3+R()*2})}
 if(p.t=='q'&&p.src){if(p.age>.48)p.returning=1;if(p.returning){const dx=p.src.x-p.x,dy=(p.src.y-p.src.h*.5)-p.y,d=Math.hypot(dx,dy);if(d<25){p.life=0}else{const a=Math.atan2(dy,dx),sp=900;p.vx=Math.cos(a)*sp;p.vy=Math.sin(a)*sp}}}
 p.vy+=(p.g||0)*dt;p.x+=p.vx*dt;p.y+=p.vy*dt;
 if(p.t=='h'){let b=0;if(p.age>.15)for(const o of ents)if(o.hp>0&&o.tm==p.tm&&Math.abs(p.x-o.x)<o.w/2+12&&p.y>o.y-o.h-12&&p.y<o.y+4)b=1;
  if(p.y>=GY){b=1;p.y=GY}if(p.vy>0)for(const q of M.pl)if(p.x>q[0]&&p.x<q[0]+q[2]&&p.y>=q[1]&&p.y-p.vy*dt<=q[1])b=1;
  if(b){p.life=0;fx(p.x,p.y,16,'#7ee08a',260);for(const o of ents)if(o.hp>0&&o.tm==p.tm&&Math.hypot(o.x-p.x,o.y-o.h/2-p.y)<120){const h=Math.round(o.mh*.2);o.hp=Math.min(o.mh,o.hp+h);TX.push({x:o.x,y:o.y-o.h-10,t:'+'+h,l:.9,c:'#7ee08a'});fx(o.x,o.y-o.h/2,8,'#7ee08a',140);o.bn=0;o.br=0;o.bl=0}}continue}
 for(const o of ents){if(o.hp<=0||o.tm==p.tm||p.life<=0)continue;if(Math.abs(p.x-o.x)>=o.w/2+5||p.y<=o.y-o.h-5||p.y>=o.y+3)continue;
  if(o.ch==3&&!o.cl&&phase(p,o))continue;
  if(o.mirror>0&&!p.reflected){p.tm=o.tm;p.vx=-p.vx*1.12;p.vy=-p.vy*1.12;p.src=o;p.reflected=1;p.age=0;p.life=Math.max(p.life,1.25);o.sw=.3;fx(p.x,p.y,12,'#a8e9ff',260);ZP.push({x1:o.x,y1:o.y-o.h*.5,x2:p.x,y2:p.y,life:.2,c:'#a8e9ff'});break}
  if(o.wp=='katana'&&(o.katRefs||0)<5&&Math.sign(p.x-o.x)==o.f){p.tm=o.tm;p.vx=-p.vx*1.1;p.vy=-p.vy;p.src=o;p.age=0;p.life=Math.max(p.life,1.5);o.sw=.3;fx(p.x,p.y,10,'#fff',240);G.sh=Math.max(G.sh,4);
   o.rf=.12;o.katRefs=(o.katRefs||0)+1;if(o.katRefs>=5)brk(o);break}
  if(p.t=='q'){p.hitTargets=p.hitTargets||[];if(!p.hitTargets.includes(o)){p.hitTargets.push(o);hit(o,p.dm,p.src,Math.sign(p.vx)*130,p.fz,1);p.returning=1;fx(p.x,p.y,8,'#ffa85c',200)}break}
  if(p.t=='p'){p.life=0;hit(o,p.dm,p.src,Math.sign(p.vx)*p.dm*3,p.fz,1);if(p.src&&p.src.hp>0){o.vx+=(p.src.x-o.x)*.9;o.vy-=100}fx(p.x,p.y,14,'#e4c47a',260);break}
  p.life=0;if(p.t!='r'&&p.t!='g'){hit(o,p.dm,p.src,Math.sign(p.vx)*p.dm*3,p.fz,1);if(p.t=='f')st(o,'bn',2.5);if(p.t=='n')bleed(o)}break
 }
 if(p.t=='g'&&p.vy>0)for(const q of M.pl)if(p.x>q[0]&&p.x<q[0]+q[2]&&p.y>q[1]&&p.y-p.vy*dt<=q[1]){p.y=q[1];p.vy=-p.vy*.5;p.vx*=.7}
 if(p.t=='r'&&(p.x<2||p.x>W-2||M.pl.some(q=>p.x>q[0]&&p.x<q[0]+q[2]&&p.y>q[1]-4&&p.y<q[1]+18)))p.life=0;
 if(p.y>GY){if(p.t=='g'){p.y=GY;p.vy=-Math.abs(p.vy)*.5;p.vx*=.7}else if(p.t!='q')p.life=0}if(p.x<-60||p.x>W+60||p.y<-300){p.life=0;p.oob=1}}
 P=P.filter(p=>{if(p.life>0)return 1;if((p.t=='r'||p.t=='g')&&!p.oob)boom(p);return 0})}
function weightedDrop(){const entries=Object.entries(DROP_WEIGHTS),total=entries.reduce((n,v)=>n+v[1],0);let r=R()*total;for(const[k,w]of entries){r-=w;if(r<=0)return k}return 'pistol'}
function spawnIT(){const r=R(),kit=r<.10,rain=!kit&&r<.13;IT.push({x:60+R()*(W-120),y:-60,vy:0,wp:rain?'rain':weightedDrop(),kit,life:26})}
function updIT(dt){for(const i of IT){i.life-=dt;const py=i.y;i.vy=Math.min(i.vy+250*dt,78);i.y+=i.vy*dt;let gy=GY;for(const p of M.pl)if(i.x>p[0]&&i.x<p[0]+p[2]&&py<=p[1]+1&&i.y>=p[1])gy=Math.min(gy,p[1]);
 if(i.y>=gy){i.y=gy;i.vy=0}i.air=i.y<gy-3;
 for(const e of ents)if(e.hp>0&&!e.z&&!e.B&&Math.abs(e.x-i.x)<28&&i.y>e.y-e.h-24&&i.y<e.y+16){if(i.kit){if(e.hp>=e.mh)continue;const h=Math.round(e.mh*.4);e.hp=Math.min(e.mh,e.hp+h);i.life=0;TX.push({x:e.x,y:e.y-e.h-18,t:'+'+h,l:.9,c:'#7ee08a'});fx(i.x,i.y-12,14,'#7ee08a',220);e.bn=0;e.br=0;e.bl=0;break}const w=WP[i.wp];e.wp=i.wp;e.am=w.am;e.katHits=0;e.katRefs=0;i.life=0;fx(i.x,i.y-12,12,w.c,220);TX.push({x:e.x,y:e.y-e.h-18,t:w.n,l:.9,c:w.c});break}}
 IT=IT.filter(i=>i.life>0)}
